<?php

namespace App\Controllers;

use \Core\View;
use App\Models\Animals;
use App\Models\RESTClient;
use \Core\Error;

/**
 * Home controller
 *
 * PHP version 5.4
 */
class Home extends \Core\Controller
{

    private $logged = false;
	/**
     * Before filter
     *
     * @return void
     */
    protected function before()
    {
        //echo "(before) ";
        //return false;
		$logged = false;
		session_start();
		if (isset($_SESSION['username'])) {
			$logged = true;
		}else{
			//Redirect to login page
			View::renderTemplate('Login/login.html');
		}
		return $logged;
    }

    /**
     * After filter
     *
     * @return void
     */
    protected function after()
    {
        //echo " (after)";
    }

    /**
     * Show the index page
     *
     * @return void
     */
    public function indexAction()
    {
	  $path = 'Home/index'.$_SESSION['level'].'.html';
	  View::renderTemplate($path);  
	}
	
	public function animalsAction()
    {
        $sites = array();
        $title ="";
        $param = array();
        
    	if($_SESSION['level'] == 0 || $_SESSION['level'] == 1 || $_SESSION['level'] == 2) {
            if(!RESTClient::callAPI("GET","https://api.thecatapi.com/v1/images/search")){
                $message = RESTClient::getRequestError();
                Error::errorHandler(1, $message, "", 0);
            }
            $json = RESTClient::getJSONResponse();
            array_push($sites, $json[0]->url);
            $title ="Gatti";
    	}
        if($_SESSION['level'] == 1 || $_SESSION['level'] == 2) {
            if(!RESTClient::callAPI("GET","https://dog.ceo/api/breeds/image/random")){
                $message = RESTClient::getRequestError();
                Error::errorHandler(1, "$message", "", 0);
            }
            $json = RESTClient::getJSONResponse();
            array_push($sites, $json->message);
            $title ="Gatti e cani";
        }
        if($_SESSION['level'] == 2 ) {
            $param['count'] = 1;
            $param['urls'] = true;
            $param['httpsUrl'] = true;
            if(!RESTClient::callAPI("GET", "http://shibe.online/api/shibes")){
                $message = RESTClient::getRequestError();
                Error::errorHandler(1, $message, "", 0);
            }
            //RESTClient::callAPI("GET","https://randomfox.ca/floof");
            $json = RESTClient::getJSONResponse();
            array_push($sites, $json[0]);
            $title ="Gatti, cani e volpi";
        }
        
        $path = 'Animal/index.html';
        View::renderTemplate($path, [
            'sites' => $sites,
            'title' => $title
        ]);  
	}
	
}
